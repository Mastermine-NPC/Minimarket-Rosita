import type { Cart } from "./catalog";
import type {
  DemoUser,
  InventoryEntry,
  CheckoutDraft,
  Delivery,
  Payment,
  Order,
} from "./commerce";
export interface RositaState {
  demoQuantity: number;
  cart: Cart;
  users: DemoUser[];
  sessionUserId: string | null;
  inventory: Record<string, InventoryEntry>;
  orders: Order[];
  checkout: CheckoutDraft;
  authError: string;
}
export type RositaAction =
  | { type: "demo/increment" }
  | { type: "demo/decrement" }
  | { type: "app/reset" }
  | { type: "cart/add" | "cart/set"; id: string; quantity: number }
  | { type: "cart/remove"; id: string }
  | { type: "cart/clear" }
  | { type: "auth/register"; user: DemoUser }
  | { type: "auth/login"; userId: string }
  | { type: "auth/logout" }
  | { type: "checkout/start"; token: string }
  | { type: "checkout/draft-delivery"; delivery: Delivery }
  | { type: "checkout/delivery"; delivery: Delivery }
  | { type: "checkout/draft-payment"; payment: Payment }
  | { type: "checkout/payment"; payment: Payment }
  | { type: "checkout/step"; step: number }
  | { type: "checkout/review" }
  | { type: "order/confirm"; token: string; id: string; createdAt: string }
  | { type: "order/advance"; id: string };
