export type CategoryId =
  | "consumibles"
  | "ferreteria"
  | "tecnologia"
  | "jugueteria"
  | "educacion-oficina"
  | "cuidado-personal";
export interface Category {
  id: CategoryId;
  name: string;
  description: string;
  imageProductId: string;
  tone: string;
}
export interface Product {
  id: string;
  name: string;
  brand: string;
  category: CategoryId;
  presentation: string;
  description: string;
  price: number;
  previousPrice?: number;
  stock: number;
  imageIndex?: number;
  featured?: boolean;
}
export type Cart = Record<string, number>;
