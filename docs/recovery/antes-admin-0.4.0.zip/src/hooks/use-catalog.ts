import { useMemo } from "react";
import { products } from "@/data/catalog";
import { useRosita } from "./use-rosita";
export function useCatalog() {
  const { state } = useRosita();
  return useMemo(
    () =>
      products.map((p) => ({
        ...p,
        stock: state.inventory[p.id].stock,
        price: state.inventory[p.id].priceCents / 100,
        previousPrice:
          p.previousPrice &&
          p.previousPrice > state.inventory[p.id].priceCents / 100
            ? p.previousPrice
            : undefined,
      })),
    [state.inventory],
  );
}
