import { Link, useSearchParams } from "react-router";
import { ArrowLeft, ShoppingBag, Leaf } from "lucide-react";
import { AuthForm } from "@/features/acceso/auth-form";
import { safeCustomerReturn } from "@/lib/customer-return";
import { useHeadingFocus } from "@/hooks/use-heading-focus";
export function AuthPage({ mode }: { mode: "login" | "registro" }) {
  const [params] = useSearchParams(),
    heading = useHeadingFocus(),
    registering = mode === "registro";
  return (
    <div className="container auth-page">
      <section className="auth-story">
        <span className="eyebrow">TU TIENDA DE SIEMPRE</span>
        <h2>
          Todo lo tuyo,
          <br />
          más cerca<span>.</span>
        </h2>
        <p>
          Prepara tu compra y prueba el recorrido completo, con la cercanía de
          Rosita.
        </p>
        <img
          src="/images/negocio-rosita.jpg"
          alt="Interior del negocio Minimarket Rosita"
        />
        <div className="auth-story-footer">
          <Leaf aria-hidden="true" />
          <span>
            Una experiencia local.
            <br />
            Sin cobros ni entregas reales.
          </span>
        </div>
      </section>
      <section className="auth-card">
        <Link className="back-link" to="/carrito">
          <ArrowLeft size={16} aria-hidden="true" />
          Volver al carrito
        </Link>
        <span className="eyebrow">
          <ShoppingBag size={16} aria-hidden="true" /> CUENTA DE DEMOSTRACIÓN
        </span>
        <h1 ref={heading} tabIndex={-1}>
          {registering ? "Un gusto tenerte aquí." : "Qué bueno verte."}
        </h1>
        <p>
          {registering
            ? "Crea una cuenta ficticia para probar tus pedidos."
            : "Ingresa con una cuenta creada en este navegador."}
        </p>
        <AuthForm
          key={mode}
          mode={mode}
          returnTo={safeCustomerReturn(params.get("volver"))}
        />
      </section>
    </div>
  );
}
