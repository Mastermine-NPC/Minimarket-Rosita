import { lazy, Suspense, type ReactNode } from "react";
import { Route, Routes } from "react-router";
import { AppLayout } from "@/components/layout/app-layout";
import { Skeleton } from "@/components/ui/skeleton";
const HomePage = lazy(() =>
  import("@/pages/home-page").then((m) => ({ default: m.HomePage })),
);
const CatalogPage = lazy(() =>
  import("@/pages/catalog-page").then((m) => ({ default: m.CatalogPage })),
);
const ProductPage = lazy(() =>
  import("@/pages/product-page").then((m) => ({ default: m.ProductPage })),
);
const CartPage = lazy(() =>
  import("@/pages/cart-page").then((m) => ({ default: m.CartPage })),
);
const SystemPage = lazy(() =>
  import("@/pages/system-page").then((m) => ({ default: m.SystemPage })),
);
const CheckPage = lazy(() =>
  import("@/pages/check-page").then((m) => ({ default: m.CheckPage })),
);
const StatePage = lazy(() =>
  import("@/pages/state-page").then((m) => ({ default: m.StatePage })),
);
const NotFoundPage = lazy(() =>
  import("@/pages/not-found-page").then((m) => ({ default: m.NotFoundPage })),
);
const AuthPage = lazy(() =>
  import("@/pages/auth-page").then((m) => ({ default: m.AuthPage })),
);
const AccountPage = lazy(() =>
  import("@/pages/account-page").then((m) => ({ default: m.AccountPage })),
);
const CheckoutPage = lazy(() =>
  import("@/pages/checkout-page").then((m) => ({ default: m.CheckoutPage })),
);
const OrdersPage = lazy(() =>
  import("@/pages/orders-page").then((m) => ({ default: m.OrdersPage })),
);
const OrderPage = lazy(() =>
  import("@/pages/order-page").then((m) => ({ default: m.OrderPage })),
);
function Page({ children }: { children: ReactNode }) {
  return (
    <Suspense
      fallback={
        <section
          className="container route-loading"
          aria-busy="true"
          aria-label="Cargando vista"
        >
          <p role="status">Cargando Rosita…</p>
          <Skeleton className="h-24 w-full" />
        </section>
      }
    >
      {children}
    </Suspense>
  );
}
export function AppRouter() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route
          path="login"
          element={
            <Page>
              <AuthPage mode="login" />
            </Page>
          }
        />
        <Route
          path="registro"
          element={
            <Page>
              <AuthPage mode="registro" />
            </Page>
          }
        />
        <Route
          path="cuenta"
          element={
            <Page>
              <AccountPage />
            </Page>
          }
        />
        <Route
          path="checkout"
          element={
            <Page>
              <CheckoutPage />
            </Page>
          }
        />
        <Route
          path="mis-pedidos"
          element={
            <Page>
              <OrdersPage />
            </Page>
          }
        />
        <Route
          path="pedido/:id"
          element={
            <Page>
              <OrderPage mode="detalle" />
            </Page>
          }
        />
        <Route
          path="pedido/:id/confirmacion"
          element={
            <Page>
              <OrderPage mode="confirmacion" />
            </Page>
          }
        />
        <Route
          path="pedido/:id/seguimiento"
          element={
            <Page>
              <OrderPage mode="seguimiento" />
            </Page>
          }
        />

        <Route
          index
          element={
            <Page>
              <HomePage />
            </Page>
          }
        />
        <Route
          path="catalogo"
          element={
            <Page>
              <CatalogPage />
            </Page>
          }
        />
        <Route
          path="categoria/:slug"
          element={
            <Page>
              <CatalogPage />
            </Page>
          }
        />
        <Route
          path="producto/:id"
          element={
            <Page>
              <ProductPage />
            </Page>
          }
        />
        <Route
          path="carrito"
          element={
            <Page>
              <CartPage />
            </Page>
          }
        />
        <Route
          path="sistema-diseno"
          element={
            <Page>
              <SystemPage />
            </Page>
          }
        />
        <Route
          path="comprobacion"
          element={
            <Page>
              <div className="technical-page container">
                <CheckPage />
              </div>
            </Page>
          }
        />
        <Route
          path="estado"
          element={
            <Page>
              <div className="technical-page container">
                <StatePage />
              </div>
            </Page>
          }
        />
        <Route
          path="*"
          element={
            <Page>
              <NotFoundPage />
            </Page>
          }
        />
      </Route>
    </Routes>
  );
}
