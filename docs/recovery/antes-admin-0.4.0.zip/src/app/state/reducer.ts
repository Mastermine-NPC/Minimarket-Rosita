import { initialState, demoProduct, emptyCheckout } from "@/data/demo";
import { productById } from "@/data/catalog";
import { deliverySchema } from "@/lib/checkout-validation";
import { prepareQuote, confirmOrder } from "@/lib/order-transaction";
import type { RositaAction, RositaState } from "@/types/state";
export function rositaReducer(
  state: RositaState,
  action: RositaAction,
): RositaState {
  switch (action.type) {
    case "demo/increment":
      return {
        ...state,
        demoQuantity: Math.min(demoProduct.stock, state.demoQuantity + 1),
      };
    case "demo/decrement":
      return { ...state, demoQuantity: Math.max(0, state.demoQuantity - 1) };
    case "app/reset":
      return {
        ...initialState,
        cart: {},
        users: [],
        orders: [],
        checkout: emptyCheckout(),
      };
    case "cart/clear":
      return { ...state, cart: {} };
    case "cart/remove": {
      const cart = { ...state.cart };
      delete cart[action.id];
      return { ...state, cart };
    }
    case "cart/add":
    case "cart/set": {
      const p = productById(action.id),
        stock = state.inventory[action.id]?.stock ?? 0;
      if (
        !p ||
        stock < 1 ||
        !Number.isSafeInteger(action.quantity) ||
        action.quantity < 1
      )
        return state;
      const wanted =
        action.type === "cart/add"
          ? (state.cart[action.id] || 0) + action.quantity
          : action.quantity;
      return {
        ...state,
        cart: { ...state.cart, [action.id]: Math.min(stock, wanted) },
      };
    }
    case "auth/register": {
      if (state.users.some((u) => u.email === action.user.email))
        return {
          ...state,
          authError:
            "Ya existe una cuenta de demostración con este correo. Inicia sesión.",
        };
      return {
        ...state,
        users: [...state.users, action.user],
        sessionUserId: action.user.id,
        authError: "",
        checkout: emptyCheckout(),
      };
    }
    case "auth/login":
      return state.users.some((u) => u.id === action.userId)
        ? {
            ...state,
            sessionUserId: action.userId,
            authError: "",
            checkout:
              state.sessionUserId === action.userId
                ? state.checkout
                : emptyCheckout(),
          }
        : state;
    case "auth/logout":
      return {
        ...state,
        sessionUserId: null,
        authError: "",
        checkout: emptyCheckout(),
      };
    case "checkout/start":
      return state.checkout.token
        ? state
        : { ...state, checkout: { ...state.checkout, token: action.token } };
    case "checkout/draft-delivery":
      return {
        ...state,
        checkout: {
          ...state.checkout,
          delivery: action.delivery,
          quote: null,
          error: "",
        },
      };
    case "checkout/delivery":
      return deliverySchema.safeParse(action.delivery).success
        ? {
            ...state,
            checkout: {
              ...state.checkout,
              delivery: action.delivery,
              step: 1,
              quote: null,
              error: "",
            },
          }
        : state;
    case "checkout/draft-payment":
      return {
        ...state,
        checkout: {
          ...state.checkout,
          payment: action.payment,
          quote: null,
          error: "",
        },
      };
    case "checkout/payment": {
      const next = {
        ...state,
        checkout: { ...state.checkout, payment: action.payment },
      };
      const result = prepareQuote(next);
      return {
        ...next,
        checkout: {
          ...next.checkout,
          step: result.quote ? 2 : 1,
          quote: result.quote,
          error: result.error,
        },
      };
    }
    case "checkout/review": {
      const result = prepareQuote(state);
      return {
        ...state,
        checkout: {
          ...state.checkout,
          quote: result.quote,
          error: result.error,
        },
      };
    }
    case "checkout/step":
      return action.step >= 0 && action.step < state.checkout.step
        ? {
            ...state,
            checkout: { ...state.checkout, step: action.step, error: "" },
          }
        : state;
    case "order/confirm":
      return confirmOrder(state, action);
    case "order/advance":
      return {
        ...state,
        orders: state.orders.map((o) =>
          o.id === action.id && o.userId === state.sessionUserId
            ? { ...o, status: Math.min(3, o.status + 1) }
            : o,
        ),
      };
  }
}
