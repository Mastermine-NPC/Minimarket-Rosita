# Carrito

CartContent se reutiliza en CartSheet y CartPage. useCart calcula líneas, contador y subtotal desde datos canónicos; Context/useReducer persiste cantidades. Añadir no descuenta stock. Continuar con mi pedido conecta el carrito al checkout; se requiere una cuenta de demostración antes de confirmar.
