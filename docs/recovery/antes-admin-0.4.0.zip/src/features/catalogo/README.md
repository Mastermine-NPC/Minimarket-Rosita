# Catálogo

ProductCard, ProductImage, ProductPrice y QuantitySelector se comparten entre inicio, catálogo, detalle y sistema. CatalogFilters compone filtros URL; catalog-logic centraliza búsqueda y ordenamiento. Productos y categorías provienen de src/data/catalog.ts.
