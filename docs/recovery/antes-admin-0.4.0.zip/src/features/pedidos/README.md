# Pedidos · 0.3.0

DeliveryForm, PaymentForm y OrderSummary; páginas de checkout, confirmación, historial y seguimiento. Transacción central en lib/order-transaction.ts; totales compartidos en lib/cart-pricing.ts.
