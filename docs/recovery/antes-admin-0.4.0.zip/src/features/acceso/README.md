# Acceso · 0.3.0

Plantilla compartida de registro/login, PasswordField y CustomerGate. Verificador Web Crypto local para claves ficticias. No equivale a seguridad de servidor.
