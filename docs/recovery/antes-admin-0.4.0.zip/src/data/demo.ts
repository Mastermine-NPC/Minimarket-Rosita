import type { RositaState } from "@/types/state";
import { products, categories as catalogCategories } from "./catalog";
export const demoProduct = { ...products[0], unit: products[0].presentation };
export const emptyCheckout = (): RositaState["checkout"] => ({
  token: "",
  step: 0,
  delivery: { recipient: "", phone: "", address: "", zone: "", reference: "" },
  payment: { method: "cash", cashAmount: "" },
  quote: null,
  error: "",
});
export const initialState: RositaState = {
  demoQuantity: 0,
  cart: {},
  users: [],
  sessionUserId: null,
  inventory: Object.fromEntries(
    products.map((p) => [
      p.id,
      { stock: p.stock, priceCents: Math.round(p.price * 100) },
    ]),
  ),
  orders: [],
  checkout: emptyCheckout(),
  authError: "",
};
export const categories = catalogCategories.map((category) => category.name);
