# Imágenes locales de Rosita

Recursos reutilizados del material del usuario y prototipo previo: rosita-logo.png, negocio-rosita.jpg, productos-rosita-atlas.jpg. El atlas contiene 18 fotografías recortadas con CSS. Seis productos adicionales muestran «Fotografía pendiente». Ver docs/RECURSOS.md. No se descargaron fotografías de comercios externos ni se generaron reseñas o garantías.
