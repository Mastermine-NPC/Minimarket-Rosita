import { useCatalog } from "@/hooks/use-catalog";
import { motionTokens } from "@/lib/motion";
import { motion } from "motion/react";
import { Link } from "react-router";
import { ArrowRight, ArrowUpRight, Sparkles, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { categories } from "@/data/catalog";
import { ProductImage } from "@/features/catalogo/product-image";
import { ProductCard } from "@/features/catalogo/product-card";
import { useMotionPreference } from "@/hooks/use-motion-preference";
import { useHeadingFocus } from "@/hooks/use-heading-focus";
export function HomePage() {
  const products = useCatalog();
  const productById = (id: string) => products.find((p) => p.id === id);
  const reduced = useMotionPreference(),
    heading = useHeadingFocus();
  return (
    <div className="home-page container">
      <section className="home-hero">
        <div className="hero-copy">
          <span className="hero-kicker">
            <span aria-hidden="true" />
            DE AQUÍ. PARA TU DÍA.
          </span>
          <motion.h1
            ref={heading}
            tabIndex={-1}
            initial={reduced ? false : { opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: reduced ? 0 : motionTokens.heroTitle,
              ease: motionTokens.ease,
            }}
          >
            Tu día tiene
            <br />
            un poco de{" "}
            <span>
              Rosita
              <svg viewBox="0 0 220 15" aria-hidden="true">
                <path d="M3 11 Q100 -2 215 7" />
              </svg>
            </span>
            .
          </motion.h1>
          <p>
            Lo que necesitas para casa, para ti
            <br className="desktop-break" /> y para esos pequeños planes.
          </p>
          <div className="hero-actions">
            <Button asChild>
              <Link to="/catalogo">
                Explorar productos <ArrowUpRight aria-hidden="true" />
              </Link>
            </Button>
            <Link className="text-link" to="/categoria/consumibles">
              Ver consumibles <ArrowRight size={16} aria-hidden="true" />
            </Link>
          </div>
        </div>
        <div className="hero-visual">
          <motion.img
            src="/images/negocio-rosita.jpg"
            alt="Interior real de Minimarket Rosita, con productos y mostradores del negocio"
            initial={reduced ? false : { scale: 1.04 }}
            animate={{ scale: 1 }}
            transition={{
              duration: reduced ? 0 : motionTokens.heroPhoto,
              ease: motionTokens.ease,
            }}
            fetchPriority="high"
          />
          <div className="hero-photo-caption">
            <span className="hero-caption-icon">
              <ShoppingBag size={23} aria-hidden="true" />
            </span>
            <span>
              <strong>Tu tienda de siempre.</strong>
              <small>Ahora, también en este prototipo.</small>
            </span>
          </div>
          <div className="hero-seal" aria-hidden="true">
            Cerca
            <br />
            de ti
            <svg viewBox="0 0 24 24">
              <path d="M12 2v20M2 12h20M5 5l14 14M5 19L19 5" />
            </svg>
          </div>
        </div>
      </section>
      <section
        className="category-section"
        aria-labelledby="categories-heading"
      >
        <div className="section-heading">
          <div>
            <p className="eyebrow">UN POCO DE TODO</p>
            <h2 id="categories-heading">¿Qué necesitas hoy?</h2>
          </div>
          <Link className="text-link" to="/catalogo">
            Ver todo <ArrowUpRight size={18} aria-hidden="true" />
          </Link>
        </div>
        <div className="category-grid">
          {categories.map((c) => (
            <Link
              key={c.id}
              className={"category-card tone-" + c.tone}
              to={"/categoria/" + c.id}
            >
              <div className="category-photo">
                <ProductImage product={productById(c.imageProductId)!} />
              </div>
              <span>{c.name}</span>
              <ArrowUpRight size={16} aria-hidden="true" />
            </Link>
          ))}
        </div>
      </section>
      <section className="featured-section" aria-labelledby="featured-heading">
        <div className="section-heading">
          <div>
            <p className="eyebrow">SELECCIÓN ROSITA</p>
            <h2 id="featured-heading">Pequeñas cosas. Buenos planes.</h2>
          </div>
          <Link className="text-link" to="/catalogo">
            Todo el catálogo <ArrowRight size={18} aria-hidden="true" />
          </Link>
        </div>
        <div className="product-grid home-products">
          {products
            .filter((p) => p.active !== false && p.featured)
            .slice(0, 8)
            .map((p) => (
              <ProductCard key={p.id} product={p} returnTo="/catalogo" />
            ))}
        </div>
      </section>
      <section className="home-promo" aria-label="Promoción de demostración">
        <div>
          <span className="promo-label">
            <Sparkles size={15} aria-hidden="true" />
            PROMOCIÓN DE DEMOSTRACIÓN
          </span>
          <h2>
            Una pausa
            <br />
            que provoca.
          </h2>
          <p>Encuentra snacks y bebidas para acompañar tu día.</p>
          <Button asChild>
            <Link to="/catalogo?ofertas=1">
              Ver precios especiales <ArrowUpRight aria-hidden="true" />
            </Link>
          </Button>
        </div>
        <motion.div
          className="promo-products"
          aria-hidden="true"
          initial={reduced ? false : { scale: 0.97 }}
          whileInView={{ scale: 1 }}
          viewport={{ once: true, amount: 0.15 }}
          transition={{ duration: reduced ? 0 : motionTokens.panel }}
        >
          <ProductImage product={products[0]} />
          <ProductImage product={products[1]} />
        </motion.div>
        <span className="promo-sticker" aria-hidden="true">
          Haz una
          <br />
          pausa.
        </span>
      </section>
      <section className="home-story" id="negocio">
        <span className="eyebrow">MINIMARKET ROSITA</span>
        <h2>
          Lo esencial está más cerca
          <br />
          de lo que piensas.
        </h2>
        <p>
          Seis categorías y la cercanía de tu minimarket peruano.
          <br />
          Explora con calma. Este prototipo no realiza cobros.
        </p>
        <Link className="text-link" to="/catalogo">
          Encuentra lo que necesitas <ArrowRight size={18} aria-hidden="true" />
        </Link>
      </section>
    </div>
  );
}
