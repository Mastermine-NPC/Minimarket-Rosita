import { useCatalog } from "@/hooks/use-catalog";
import { useEffect, useRef, useState } from "react";
import { Link, useLocation, useParams, useSearchParams } from "react-router";
import { SlidersHorizontal, SearchX, ArrowRight } from "lucide-react";
import { subcategoryById, validSubcategory } from "@/data/subcategories";
import "@/styles/subcategories.css";
import { categoryById } from "@/data/catalog";
import { ProductCard } from "@/features/catalogo/product-card";
import { CatalogFilters } from "@/features/catalogo/catalog-filters";
import {
  filterProducts,
  getFilters,
  sortOptions,
} from "@/features/catalogo/catalog-logic";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { useMediaQuery } from "@/hooks/use-media-query";
export function CatalogPage() {
  const products = useCatalog();
  const { slug } = useParams(),
    category = slug ? categoryById(slug) : undefined,
    [params, SetParams] = useSearchParams(),
    f = getFilters(params),
    [open, Open] = useState(false),
    desktop = useMediaQuery("(min-width: 1024px)"),
    location = useLocation(),
    heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => {
    if (location.state?.focusSearchResult) heading.current?.focus();
  }, [location.key, location.state]);
  useEffect(() => {
    if (
      params.has("subcategoria") &&
      (!category || !validSubcategory(category.id, f.subcategory))
    ) {
      const next = new URLSearchParams(params);
      next.delete("subcategoria");
      SetParams(next, { replace: true });
    }
  }, [category, params, SetParams, f.subcategory]);
  const selectedSubcategory =
    category && validSubcategory(category.id, f.subcategory)
      ? subcategoryById(f.subcategory)
      : undefined;
  const list = filterProducts(products, params, category?.id),
    brands = [
      ...new Set(
        products
          .filter(
            (p) =>
              p.active !== false && (!category || p.category === category.id),
          )
          .map((p) => p.brand),
      ),
    ].sort(),
    active =
      Number(!!selectedSubcategory) +
      Number(!!f.brand) +
      Number(f.max < 200) +
      Number(f.inStock) +
      Number(f.offers);
  function update(key: string, value: string) {
    // La URL ya refleja el último cambio aunque React aún esté renderizando.
    const next = new URLSearchParams(window.location.search);
    if (key === "*") {
      next.delete("subcategoria");
      next.delete("marca");
      next.delete("max");
      next.delete("disponibles");
      next.delete("ofertas");
    } else if (value) next.set(key, value);
    else next.delete(key);
    SetParams(next, { replace: true });
  }
  const filters = (
    <CatalogFilters
      params={params}
      update={update}
      brands={brands}
      category={category?.id}
      products={products}
    />
  );
  if (slug && !category)
    return (
      <div className="container empty-page">
        <SearchX aria-hidden="true" />
        <h1 tabIndex={-1}>No encontramos esa categoría</h1>
        <p>Explora nuestras seis categorías desde el catálogo.</p>
        <Button asChild>
          <Link to="/catalogo">Ver catálogo</Link>
        </Button>
      </div>
    );
  return (
    <div className="container catalog-page">
      <nav className="breadcrumbs" aria-label="Ruta actual">
        <Link to="/">Inicio</Link>
        <span>/</span>
        <span aria-current="page">{category?.name || "Catálogo"}</span>
      </nav>
      <div
        className={
          "catalog-heading " + (category ? "tone-" + category.tone : "")
        }
      >
        <div>
          <span className="eyebrow">
            {category ? "LO TUYO, MÁS CERCA" : "TODO EN UN SOLO LUGAR"}
          </span>
          <h1 ref={heading} tabIndex={-1}>
            {f.query
              ? "Resultados para “" + f.query + "”"
              : category?.name || "Encuentra lo que necesitas."}
          </h1>
          <p>
            {category?.description ||
              "Productos para tu casa, tus estudios y tu día a día."}
          </p>
        </div>
        <span className="catalog-heading-note">
          Precios en soles.
          <br />
          Datos de demostración.
        </span>
      </div>
      <div className="catalog-layout">
        {desktop && (
          <aside className="filter-sidebar" aria-label="Filtros de productos">
            {filters}
          </aside>
        )}
        <section
          className="catalog-results"
          aria-label="Resultados del catálogo"
        >
          <div className="catalog-toolbar">
            <p role="status" aria-live="polite">
              {list.length} {list.length === 1 ? "producto" : "productos"}
              {active
                ? " · " +
                  active +
                  (active === 1 ? " filtro activo" : " filtros activos")
                : ""}
            </p>
            <div className="catalog-controls">
              {!desktop && (
                <Button variant="outline" onClick={() => Open(true)}>
                  <SlidersHorizontal size={16} aria-hidden="true" />
                  Filtros{active ? " (" + active + ")" : ""}
                </Button>
              )}
              <label htmlFor="catalog-sort">
                Ordenar por{" "}
                <select
                  id="catalog-sort"
                  value={f.sort}
                  onChange={(e) =>
                    update(
                      "orden",
                      e.target.value === "relevancia" ? "" : e.target.value,
                    )
                  }
                >
                  {sortOptions.map(([value, label]) => (
                    <option key={value} value={value}>
                      {label}
                    </option>
                  ))}
                </select>
              </label>
            </div>
          </div>
          {(active > 0 || f.query) && (
            <div className="active-filters">
              {selectedSubcategory && (
                <div className="subcategory-selection">
                  <span>
                    Subcategoría: <strong>{selectedSubcategory.name}</strong>
                  </span>
                  <Button
                    variant="ghost"
                    onClick={() => update("subcategoria", "")}
                    aria-label={
                      "Quitar subcategoría " + selectedSubcategory.name
                    }
                  >
                    Quitar selección ×
                  </Button>
                </div>
              )}
              {f.query && <span>“{f.query}”</span>}
              {f.brand && <span>{f.brand}</span>}
              {f.max < 200 && <span>Hasta S/ {f.max}</span>}
              {f.inStock && <span>Disponibles</span>}
              {f.offers && <span>Ofertas de prueba</span>}
              <Button variant="link" onClick={() => SetParams({})}>
                Limpiar búsqueda y filtros
              </Button>
            </div>
          )}
          {list.length ? (
            <div className="product-grid catalog-products">
              {list.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          ) : (
            <div className="catalog-empty">
              <span className="empty-icon">
                <SearchX size={36} aria-hidden="true" />
              </span>
              <h2>No encontramos coincidencias</h2>
              <p>Prueba otro nombre, otra marca o amplía tus filtros.</p>
              <Button onClick={() => SetParams({})}>
                Limpiar búsqueda y filtros <ArrowRight aria-hidden="true" />
              </Button>
            </div>
          )}
        </section>
      </div>
      <Sheet open={open && !desktop} onOpenChange={Open}>
        <SheetContent side="left" className="filter-sheet">
          <SheetHeader>
            <SheetTitle>Filtrar productos</SheetTitle>
            <SheetDescription>
              Ajusta tu selección. Los resultados se actualizan al instante.
            </SheetDescription>
          </SheetHeader>
          <div className="filter-sheet-scroll">{!desktop && filters}</div>
          <div className="filter-sheet-footer">
            <Button className="full-width" onClick={() => Open(false)}>
              Ver {list.length} {list.length === 1 ? "producto" : "productos"}
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
