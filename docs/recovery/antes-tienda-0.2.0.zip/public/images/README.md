Imágenes locales. El logotipo de Rosita se conserva del material del proyecto Framer previo; no se ha rediseñado. Agregar aquí las fotografías autorizadas en etapas posteriores.
