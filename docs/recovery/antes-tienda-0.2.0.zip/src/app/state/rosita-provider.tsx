import {
  useCallback,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { toast } from "sonner";
import { RositaContext } from "./context";
import { rositaReducer } from "./reducer";
import {
  readRositaState,
  resetRositaStorage,
  writeRositaState,
} from "@/lib/storage";
export function RositaProvider({ children }: { children: ReactNode }) {
  const [initial] = useState(readRositaState);
  const [notice, setNotice] = useState(initial.notice);
  const [state, dispatch] = useReducer(rositaReducer, initial.data);
  const last = useRef(initial.data);
  const blocked = useRef(initial.status === "future");
  useEffect(() => {
    if (state === last.current || blocked.current) return;
    const result = writeRositaState(state);
    last.current = state;
    if (!result.ok) toast.error(result.message);
  }, [state]);
  const reset = useCallback(() => {
    const result = resetRositaStorage();
    if (!result.ok) {
      toast.error(result.message);
      return;
    }
    setNotice("");
    blocked.current = false;
    dispatch({ type: "app/reset" });
    toast.success("Datos de Rosita restablecidos", {
      description: "Las claves de otras aplicaciones se conservaron.",
    });
  }, []);
  const value = useMemo(
    () => ({ state, dispatch, reset, initialNotice: notice }),
    [state, reset, notice],
  );
  return (
    <RositaContext.Provider value={value}>{children}</RositaContext.Provider>
  );
}
