import { initialState, demoProduct } from "@/data/demo";
import type { RositaAction, RositaState } from "@/types/state";
export function rositaReducer(
  state: RositaState,
  action: RositaAction,
): RositaState {
  switch (action.type) {
    case "demo/increment":
      return {
        ...state,
        demoQuantity: Math.min(demoProduct.stock, state.demoQuantity + 1),
      };
    case "demo/decrement":
      return { ...state, demoQuantity: Math.max(0, state.demoQuantity - 1) };
    case "app/reset":
      return { ...initialState };
  }
}
