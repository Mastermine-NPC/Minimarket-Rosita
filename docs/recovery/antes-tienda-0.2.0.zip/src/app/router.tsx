import { lazy, Suspense, type ReactNode } from "react";
import { Navigate, Route, Routes } from "react-router";
import { AppLayout } from "@/components/layout/app-layout";
import { Skeleton } from "@/components/ui/skeleton";
const CheckPage = lazy(() =>
  import("@/pages/check-page").then((module) => ({
    default: module.CheckPage,
  })),
);
const StatePage = lazy(() =>
  import("@/pages/state-page").then((module) => ({
    default: module.StatePage,
  })),
);
function Page({ children }: { children: ReactNode }) {
  return (
    <Suspense
      fallback={
        <section aria-busy="true" aria-label="Cargando vista">
          <p role="status">Cargando vista de Rosita…</p>
          <Skeleton className="h-24 w-full" />
        </section>
      }
    >
      {children}
    </Suspense>
  );
}
export function AppRouter() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route
          index
          element={
            <Page>
              <CheckPage />
            </Page>
          }
        />
        <Route
          path="estado"
          element={
            <Page>
              <StatePage />
            </Page>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
