export interface RositaState {
  demoQuantity: number;
}
export type RositaAction =
  | { type: "demo/increment" }
  | { type: "demo/decrement" }
  | { type: "app/reset" };
