export const motionTokens = {
  control: 0.15,
  panel: 0.24,
  ease: [0.2, 0, 0, 1] as const,
};
