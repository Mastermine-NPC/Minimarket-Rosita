import { z } from "zod";
import { initialState, demoProduct } from "@/data/demo";
import type { RositaState } from "@/types/state";
export const STORAGE_PREFIX = "minimarket-rosita:";
export const STATE_KEY = `${STORAGE_PREFIX}app`;
export const STORAGE_VERSION = 1;
const stateSchema = z
  .object({ demoQuantity: z.number().int().min(0).max(demoProduct.stock) })
  .strict();
const envelopeSchema = z.object({
  version: z.literal(STORAGE_VERSION),
  data: stateSchema,
});
type StorageStatus = "empty" | "loaded" | "invalid" | "future" | "unavailable";
export interface StoredState {
  data: RositaState;
  status: StorageStatus;
  notice: string;
}
function targetStorage(storage?: Storage): Storage {
  if (storage) return storage;
  if (typeof window === "undefined")
    throw new Error("Almacenamiento no disponible");
  return window.localStorage;
}
export function readRositaState(storage?: Storage): StoredState {
  try {
    const raw = targetStorage(storage).getItem(STATE_KEY);
    if (raw === null)
      return { data: { ...initialState }, status: "empty", notice: "" };
    const value: unknown = JSON.parse(raw);
    if (
      typeof value === "object" &&
      value !== null &&
      "version" in value &&
      typeof value.version === "number" &&
      value.version > STORAGE_VERSION
    ) {
      return {
        data: { ...initialState },
        status: "future",
        notice:
          "Hay datos de una versión más reciente. Se usa una sesión temporal sin sobrescribirlos; restablece Rosita para volver a guardar.",
      };
    }
    const result = envelopeSchema.safeParse(value);
    if (!result.success)
      return {
        data: { ...initialState },
        status: "invalid",
        notice:
          "Los datos de Rosita no eran válidos. Se inició un estado de prueba vacío; la próxima modificación guardará un formato válido.",
      };
    return { data: result.data.data, status: "loaded", notice: "" };
  } catch (error) {
    const invalid = error instanceof SyntaxError;
    return {
      data: { ...initialState },
      status: invalid ? "invalid" : "unavailable",
      notice: invalid
        ? "No se pudo leer el contenido guardado de Rosita. Se inició un estado vacío sin afectar otros datos del navegador."
        : "El navegador no permite almacenamiento local. Puedes probar la interfaz, pero los cambios podrían perderse al recargar.",
    };
  }
}
export function writeRositaState(
  state: RositaState,
  storage?: Storage,
): { ok: boolean; message?: string } {
  try {
    const data = stateSchema.parse(state);
    targetStorage(storage).setItem(
      STATE_KEY,
      JSON.stringify({ version: STORAGE_VERSION, data }),
    );
    return { ok: true };
  } catch {
    return {
      ok: false,
      message:
        "No se pudieron guardar los datos de prueba. Comprueba el almacenamiento del navegador.",
    };
  }
}
export function resetRositaStorage(storage?: Storage): {
  ok: boolean;
  message?: string;
} {
  try {
    const target = targetStorage(storage);
    const owned = Array.from({ length: target.length }, (_, i) =>
      target.key(i),
    ).filter(
      (key): key is string => key !== null && key.startsWith(STORAGE_PREFIX),
    );
    for (const key of owned) target.removeItem(key);
    return { ok: true };
  } catch {
    return {
      ok: false,
      message:
        "No se pudieron restablecer los datos locales. No se modificaron datos de otras aplicaciones.",
    };
  }
}
