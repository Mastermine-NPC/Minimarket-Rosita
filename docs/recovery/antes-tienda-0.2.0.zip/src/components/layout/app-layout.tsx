import { NavLink, Outlet } from "react-router";
import { ArrowUpRight, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useRosita } from "@/hooks/use-rosita";
export function AppLayout() {
  const { initialNotice } = useRosita();
  return (
    <>
      <a className="skip-link" href="#contenido">
        Saltar al contenido
      </a>
      <div className="environment-strip">
        Prototipo académico · Entorno local · Sin cobros
      </div>
      <header className="site-header">
        <div className="header-inner">
          <NavLink
            className="brand"
            to="/"
            aria-label="Minimarket Rosita, comprobación"
          >
            <img src="/images/rosita-logo.png" alt="" />
            <span>
              <small>MINIMARKET</small>
              <strong>
                Rosita<span>.</span>
              </strong>
            </span>
          </NavLink>
          <nav aria-label="Navegación de comprobación">
            <NavLink to="/" end>
              Comprobación
            </NavLink>
            <NavLink to="/estado">
              Estado compartido <ArrowUpRight size={16} aria-hidden="true" />
            </NavLink>
          </nav>
          <Badge variant="secondary">
            <CheckCircle2 aria-hidden="true" /> Base instalada
          </Badge>
        </div>
      </header>
      <main id="contenido" className="page-container" tabIndex={-1}>
        {initialNotice && (
          <Alert className="storage-notice">
            <AlertTitle>Información de almacenamiento</AlertTitle>
            <AlertDescription>{initialNotice}</AlertDescription>
          </Alert>
        )}
        <Outlet />
      </main>
      <footer className="site-footer">
        <span>Minimarket Rosita · Base frontend 0.1.0</span>
        <span>React + TypeScript · Datos ficticios</span>
      </footer>
    </>
  );
}
