import type { RositaState } from "@/types/state";
export const demoProduct = {
  id: "ROS-001",
  name: "Gaseosa Coca-Cola",
  presentation: "Botella · 600 ml",
  price: 3.5,
  stock: 24,
} as const;
export const initialState: RositaState = { demoQuantity: 0 };
export const categories = [
  "Consumibles",
  "Ferretería",
  "Tecnología",
  "Juguetería",
  "Educación y oficina",
  "Cuidado personal",
] as const;
