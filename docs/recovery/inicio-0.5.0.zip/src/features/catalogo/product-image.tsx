import { Package } from "lucide-react";
import type { Product } from "@/types/catalog";
export function ProductImage({
  product,
  className = "",
}: {
  product: Product;
  className?: string;
}) {
  if (product.imageSrc)
    return (
      <div className={"product-image product-illustration " + className}>
        <img
          src={product.imageSrc}
          alt={
            (product.imageIsIllustration
              ? "Ilustración de demostración: "
              : "") + product.name
          }
          loading="lazy"
        />
        {product.imageIsIllustration && (
          <span>Ilustración · sin fotografía</span>
        )}
      </div>
    );
  if (product.imageIndex === undefined)
    return (
      <div
        className={"product-image photo-placeholder " + className}
        role="img"
        aria-label={"Fotografía pendiente de " + product.name}
      >
        <Package size={40} aria-hidden="true" />
        <span>Fotografía pendiente</span>
      </div>
    );
  const i = product.imageIndex;
  return (
    <div
      className={"product-image " + className}
      role="img"
      aria-label={product.name + " · " + product.presentation}
      style={{
        backgroundImage: "url(/images/productos-rosita-atlas.jpg)",
        backgroundSize: "300% 600%",
        backgroundPosition: `${(i % 3) * 50}% ${Math.floor(i / 3) * 20}%`,
      }}
    >
      <span className="atlas-mask" aria-hidden="true" />
    </div>
  );
}
