import { Link } from "react-router";
import { categories } from "@/data/catalog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { getFilters } from "./catalog-logic";
import { formatPEN } from "@/lib/currency";
export function CatalogFilters({
  params,
  update,
  brands,
  category,
  onNavigate,
}: {
  params: URLSearchParams;
  update: (key: string, value: string) => void;
  brands: string[];
  category?: string;
  onNavigate?: () => void;
}) {
  const f = getFilters(params);
  return (
    <div className="catalog-filters">
      <div className="filter-section">
        <h2>Categorías</h2>
        <nav aria-label="Categorías del catálogo">
          <Link
            className={!category ? "active" : ""}
            to="/catalogo"
            onClick={onNavigate}
          >
            Todos los productos
          </Link>
          {categories.map((c) => (
            <Link
              key={c.id}
              className={category === c.id ? "active" : ""}
              to={"/categoria/" + c.id}
              onClick={onNavigate}
            >
              {c.name}
            </Link>
          ))}
        </nav>
      </div>
      <div className="filter-section">
        <h2>Refina tu búsqueda</h2>
        <label htmlFor="filter-brand">Marca</label>
        <select
          id="filter-brand"
          value={f.brand}
          onChange={(e) => update("marca", e.target.value)}
        >
          <option value="">Todas las marcas</option>
          {f.brand && !brands.includes(f.brand) && (
            <option value={f.brand}>{f.brand} (sin coincidencias)</option>
          )}
          {brands.map((brand) => (
            <option key={brand}>{brand}</option>
          ))}
        </select>
        <label htmlFor="filter-price">
          Precio máximo <strong>{formatPEN(f.max)}</strong>
        </label>
        <Input
          id="filter-price"
          type="range"
          min={1}
          max={200}
          step={1}
          value={f.max}
          onChange={(e) =>
            update("max", e.target.value === "200" ? "" : e.target.value)
          }
        />
        <div className="range-labels">
          <span>S/ 1</span>
          <span>S/ 200</span>
        </div>
        <label className="checkbox-label">
          <Checkbox
            checked={f.inStock}
            onCheckedChange={(checked) =>
              update("disponibles", checked === true ? "1" : "")
            }
          />
          Solo disponibles
        </label>
        <label className="checkbox-label">
          <Checkbox
            checked={f.offers}
            onCheckedChange={(checked) =>
              update("ofertas", checked === true ? "1" : "")
            }
          />
          Ofertas de prueba
        </label>
        <Button variant="outline" onClick={() => update("*", "")}>
          Limpiar filtros
        </Button>
      </div>
      <p className="filter-note">
        Precios e inventario de demostración. No se realizan cobros.
      </p>
    </div>
  );
}
