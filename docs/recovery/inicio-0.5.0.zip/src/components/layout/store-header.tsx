import { useRosita } from "@/hooks/use-rosita";
import { useNavigate } from "react-router";
import { Package, LogOut } from "lucide-react";
import { motionTokens } from "@/lib/motion";
import { motion } from "motion/react";
import { useMotionPreference } from "@/hooks/use-motion-preference";
import { useState } from "react";
import { Link, NavLink } from "react-router";
import {
  ShoppingBag,
  UserRound,
  Menu,
  ArrowUpRight,
  MapPin,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
  SheetDescription,
  SheetHeader,
  SheetClose,
} from "@/components/ui/sheet";
import { categories } from "@/data/catalog";
import { useCart } from "@/hooks/use-cart";
import { StoreSearch } from "./store-search";
export function StoreHeader() {
  const reduced = useMotionPreference();
  const { count, open } = useCart(),
    [menu, MenuOpen] = useState(false),
    navigate = useNavigate();
  const { state, dispatch } = useRosita();
  const user = state.users.find((u) => u.id === state.sessionUserId);
  return (
    <>
      <div className="store-topbar">
        <div>
          <span>Tu minimarket de siempre, más cerca.</span>
          <span>Prototipo · Sin cobros</span>
        </div>
      </div>
      <header className="store-header">
        <div className="store-header-main">
          <Link
            className="store-brand"
            to="/"
            aria-label="Minimarket Rosita, inicio"
          >
            <img
              src="/images/rosita-logo.png"
              alt="Logotipo de Minimarket Rosita"
            />
            <span>
              <small>MINIMARKET</small>
              <strong>
                Rosita<span>.</span>
              </strong>
            </span>
          </Link>
          <StoreSearch />
          <div className="header-actions">
            <Button variant="ghost" className="account-trigger" asChild>
              <Link
                to={
                  user?.role === "admin"
                    ? "/admin"
                    : user
                      ? "/cuenta"
                      : "/login"
                }
                aria-label={
                  user
                    ? "Mi cuenta: " + user.name
                    : "Iniciar sesión de demostración"
                }
              >
                <UserRound size={22} aria-hidden="true" />
                <span>{user ? user.name.split(" ")[0] : "Mi cuenta"}</span>
              </Link>
            </Button>
            <Button variant="ghost" className="orders-trigger" asChild>
              <Link
                to={user?.role === "admin" ? "/admin/pedidos" : "/mis-pedidos"}
                aria-label={
                  user?.role === "admin"
                    ? "Pedidos administrativos"
                    : "Mis pedidos"
                }
              >
                <Package size={22} aria-hidden="true" />
                <span>Pedidos</span>
              </Link>
            </Button>
            {user && (
              <Button
                variant="ghost"
                size="icon"
                className="logout-trigger"
                aria-label="Cerrar sesión"
                onClick={() => {
                  dispatch({ type: "auth/logout" });
                  navigate("/login");
                }}
              >
                <LogOut size={18} aria-hidden="true" />
              </Button>
            )}
            <Button
              variant="ghost"
              className="cart-trigger"
              onClick={open}
              aria-label={
                "Abrir carrito, " +
                count +
                (count === 1 ? " unidad" : " unidades")
              }
            >
              <span className="cart-icon">
                <ShoppingBag size={23} aria-hidden="true" />
                <motion.span
                  key={count}
                  className="cart-count"
                  aria-live="polite"
                  aria-label={count + " unidades en carrito"}
                  initial={reduced ? false : { scale: 0.8 }}
                  animate={{ scale: 1 }}
                  transition={{
                    duration: reduced ? 0 : motionTokens.control,
                    ease: motionTokens.ease,
                  }}
                >
                  {count}
                </motion.span>
              </span>
              <span>Carrito</span>
            </Button>
          </div>
        </div>
        <div className="store-nav-wrap">
          <div className="store-navigation">
            <Sheet open={menu} onOpenChange={MenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" className="menu-trigger">
                  <Menu size={18} aria-hidden="true" />
                  Categorías
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="menu-sheet">
                <SheetHeader>
                  <SheetTitle>Encuentra lo que necesitas</SheetTitle>
                  <SheetDescription>
                    Seis categorías, una sola tienda.
                  </SheetDescription>
                </SheetHeader>
                <nav aria-label="Menú de categorías">
                  <SheetClose asChild>
                    <NavLink to="/">Inicio</NavLink>
                  </SheetClose>
                  <SheetClose asChild>
                    <NavLink to="/catalogo">
                      Todo el catálogo{" "}
                      <ArrowUpRight size={18} aria-hidden="true" />
                    </NavLink>
                  </SheetClose>
                  {categories.map((c) => (
                    <SheetClose asChild key={c.id}>
                      <NavLink to={"/categoria/" + c.id}>{c.name}</NavLink>
                    </SheetClose>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
            <nav className="main-links" aria-label="Navegación de tienda">
              <NavLink to="/" end>
                Inicio
              </NavLink>
              <NavLink to="/catalogo">Catálogo</NavLink>
              <Link to="/catalogo?ofertas=1">Ofertas de prueba</Link>
            </nav>
            <nav className="category-inline" aria-label="Categorías de tienda">
              {categories.map((c) => (
                <NavLink key={c.id} to={"/categoria/" + c.id}>
                  {c.name}
                </NavLink>
              ))}
            </nav>
            <span className="store-location">
              <MapPin size={15} aria-hidden="true" />
              Tu tienda cercana
            </span>
          </div>
        </div>
      </header>
    </>
  );
}
