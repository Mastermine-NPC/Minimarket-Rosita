import { productImages } from "@/data/product-images";
import type { RositaState } from "@/types/state";
import type { Product } from "@/types/catalog";
export function currentProducts(
  state: Pick<RositaState, "products" | "inventory">,
): Product[] {
  return state.products.map((p) => {
    const inventory = state.inventory[p.id],
      image = productImages.find((i) => i.key === p.imageKey);
    return {
      ...p,
      stock: inventory.stock,
      price: inventory.priceCents / 100,
      previousPrice:
        p.previousPrice && p.previousPrice > inventory.priceCents / 100
          ? p.previousPrice
          : undefined,
      imageIndex: image?.index,
      imageSrc: image?.src || undefined,
      imageIsIllustration: image?.illustration,
    };
  });
}
