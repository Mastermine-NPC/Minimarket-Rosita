export const motionTokens = {
  control: 0.15,
  panel: 0.24,
  heroTitle: 0.28,
  heroPhoto: 0.6,
  search: 0.2,
  ease: [0.2, 0, 0, 1] as const,
};
