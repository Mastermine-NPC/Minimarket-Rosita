import type { RositaState } from "@/types/state";
import { products, categories as catalogCategories } from "./catalog";
export const demoProduct = { ...products[0], unit: products[0].presentation };
export const initialState: RositaState = { demoQuantity: 0, cart: {} };
export const categories = catalogCategories.map((category) => category.name);
