# Carrito

CartContent se reutiliza en CartSheet y CartPage. useCart calcula líneas, contador y subtotal desde datos canónicos; Context/useReducer persiste cantidades. Añadir no descuenta stock. Checkout permanece deshabilitado con explicación de próxima etapa.
