import { initialState, demoProduct } from "@/data/demo";
import { productById } from "@/data/catalog";
import type { RositaAction, RositaState } from "@/types/state";
export function rositaReducer(
  state: RositaState,
  action: RositaAction,
): RositaState {
  switch (action.type) {
    case "demo/increment":
      return {
        ...state,
        demoQuantity: Math.min(demoProduct.stock, state.demoQuantity + 1),
      };
    case "demo/decrement":
      return { ...state, demoQuantity: Math.max(0, state.demoQuantity - 1) };
    case "app/reset":
      return { ...initialState, cart: {} };
    case "cart/clear":
      return { ...state, cart: {} };
    case "cart/remove": {
      const cart = { ...state.cart };
      delete cart[action.id];
      return { ...state, cart };
    }
    case "cart/add":
    case "cart/set": {
      const product = productById(action.id);
      if (
        !product ||
        product.stock < 1 ||
        !Number.isSafeInteger(action.quantity) ||
        action.quantity < 1
      )
        return state;
      const requested =
        action.type === "cart/add"
          ? (state.cart[action.id] || 0) + action.quantity
          : action.quantity;
      return {
        ...state,
        cart: {
          ...state.cart,
          [action.id]: Math.min(product.stock, requested),
        },
      };
    }
  }
}
