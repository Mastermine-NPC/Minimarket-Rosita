import { lazy, Suspense, type ReactNode } from "react";
import { Route, Routes } from "react-router";
import { AppLayout } from "@/components/layout/app-layout";
import { Skeleton } from "@/components/ui/skeleton";
const HomePage = lazy(() =>
  import("@/pages/home-page").then((m) => ({ default: m.HomePage })),
);
const CatalogPage = lazy(() =>
  import("@/pages/catalog-page").then((m) => ({ default: m.CatalogPage })),
);
const ProductPage = lazy(() =>
  import("@/pages/product-page").then((m) => ({ default: m.ProductPage })),
);
const CartPage = lazy(() =>
  import("@/pages/cart-page").then((m) => ({ default: m.CartPage })),
);
const SystemPage = lazy(() =>
  import("@/pages/system-page").then((m) => ({ default: m.SystemPage })),
);
const CheckPage = lazy(() =>
  import("@/pages/check-page").then((m) => ({ default: m.CheckPage })),
);
const StatePage = lazy(() =>
  import("@/pages/state-page").then((m) => ({ default: m.StatePage })),
);
const NotFoundPage = lazy(() =>
  import("@/pages/not-found-page").then((m) => ({ default: m.NotFoundPage })),
);
function Page({ children }: { children: ReactNode }) {
  return (
    <Suspense
      fallback={
        <section
          className="container route-loading"
          aria-busy="true"
          aria-label="Cargando vista"
        >
          <p role="status">Cargando Rosita…</p>
          <Skeleton className="h-24 w-full" />
        </section>
      }
    >
      {children}
    </Suspense>
  );
}
export function AppRouter() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route
          index
          element={
            <Page>
              <HomePage />
            </Page>
          }
        />
        <Route
          path="catalogo"
          element={
            <Page>
              <CatalogPage />
            </Page>
          }
        />
        <Route
          path="categoria/:slug"
          element={
            <Page>
              <CatalogPage />
            </Page>
          }
        />
        <Route
          path="producto/:id"
          element={
            <Page>
              <ProductPage />
            </Page>
          }
        />
        <Route
          path="carrito"
          element={
            <Page>
              <CartPage />
            </Page>
          }
        />
        <Route
          path="sistema-diseno"
          element={
            <Page>
              <SystemPage />
            </Page>
          }
        />
        <Route
          path="comprobacion"
          element={
            <Page>
              <div className="technical-page container">
                <CheckPage />
              </div>
            </Page>
          }
        />
        <Route
          path="estado"
          element={
            <Page>
              <div className="technical-page container">
                <StatePage />
              </div>
            </Page>
          }
        />
        <Route
          path="*"
          element={
            <Page>
              <NotFoundPage />
            </Page>
          }
        />
      </Route>
    </Routes>
  );
}
