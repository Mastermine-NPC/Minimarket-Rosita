import type { Cart } from "./catalog";
export interface RositaState {
  demoQuantity: number;
  cart: Cart;
}
export type RositaAction =
  | { type: "demo/increment" }
  | { type: "demo/decrement" }
  | { type: "app/reset" }
  | { type: "cart/add"; id: string; quantity: number }
  | { type: "cart/set"; id: string; quantity: number }
  | { type: "cart/remove"; id: string }
  | { type: "cart/clear" };
