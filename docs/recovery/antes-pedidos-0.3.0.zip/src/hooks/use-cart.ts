import { useMemo } from "react";
import { toast } from "sonner";
import { useRosita } from "./use-rosita";
import { products } from "@/data/catalog";
import type { Product } from "@/types/catalog";
export function useCart() {
  const { state, dispatch, setCartOpen } = useRosita();
  const lines = useMemo(
    () =>
      products
        .filter((p) => (state.cart[p.id] || 0) > 0)
        .map((product) => ({
          product,
          quantity: state.cart[product.id],
          lineTotal:
            (Math.round(product.price * 100) * state.cart[product.id]) / 100,
        })),
    [state.cart],
  );
  const count = lines.reduce((sum, line) => sum + line.quantity, 0),
    subtotal =
      lines.reduce((sum, line) => sum + Math.round(line.lineTotal * 100), 0) /
      100;
  function add(product: Product, quantity = 1) {
    if (!Number.isSafeInteger(quantity) || quantity < 1) return;
    if ((state.cart[product.id] || 0) >= product.stock) {
      toast.info("Ya tienes todo el stock disponible en tu carrito.");
      return;
    }
    dispatch({ type: "cart/add", id: product.id, quantity });
    toast.success("Agregado al carrito", {
      id: "cart-" + product.id,
      description: product.name,
      action: { label: "Ver carrito", onClick: () => setCartOpen(true) },
    });
  }
  function remove(id: string) {
    dispatch({ type: "cart/remove", id });
    toast.info("Producto eliminado del carrito.");
  }
  return {
    lines,
    count,
    subtotal,
    cart: state.cart,
    add,
    remove,
    set: (id: string, quantity: number) =>
      dispatch({ type: "cart/set", id, quantity }),
    clear: () => dispatch({ type: "cart/clear" }),
    open: () => setCartOpen(true),
  };
}
