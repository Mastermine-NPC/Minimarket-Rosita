import { z } from "zod";
import { initialState, demoProduct } from "@/data/demo";
import { productById } from "@/data/catalog";
import type { RositaState } from "@/types/state";
import type { Cart } from "@/types/catalog";
export const STORAGE_PREFIX = "minimarket-rosita:";
export const STATE_KEY = `${STORAGE_PREFIX}app`;
export const STORAGE_VERSION = 2;
const legacySchema = z
  .object({ demoQuantity: z.number().int().min(0).max(demoProduct.stock) })
  .strict();
const stateSchema = legacySchema.extend({
  cart: z.record(z.string(), z.number().int().min(1).max(9999)),
});
const envelopeSchema = z.object({
  version: z.literal(STORAGE_VERSION),
  data: stateSchema,
});
type StorageStatus =
  | "empty"
  | "loaded"
  | "migrated"
  | "repaired"
  | "invalid"
  | "future"
  | "unavailable";
export interface StoredState {
  data: RositaState;
  status: StorageStatus;
  notice: string;
}
function empty(): RositaState {
  return { ...initialState, cart: {} };
}
function targetStorage(storage?: Storage): Storage {
  if (storage) return storage;
  if (typeof window === "undefined")
    throw new Error("Almacenamiento no disponible");
  return window.localStorage;
}
function normalizeCart(cart: Cart): Cart {
  return Object.fromEntries(
    Object.entries(cart).flatMap(([id, quantity]) => {
      const product = productById(id);
      return product && product.stock > 0
        ? [[id, Math.min(quantity, product.stock)]]
        : [];
    }),
  );
}
export function readRositaState(storage?: Storage): StoredState {
  try {
    const raw = targetStorage(storage).getItem(STATE_KEY);
    if (raw === null) return { data: empty(), status: "empty", notice: "" };
    const value: unknown = JSON.parse(raw);
    if (
      typeof value === "object" &&
      value !== null &&
      "version" in value &&
      typeof value.version === "number"
    ) {
      if (value.version > STORAGE_VERSION)
        return {
          data: empty(),
          status: "future",
          notice:
            "Hay datos de una versión más reciente. Se usa una sesión temporal sin sobrescribirlos; restablece Rosita para volver a guardar.",
        };
      if (value.version === 1 && "data" in value) {
        const legacy = legacySchema.safeParse(value.data);
        if (legacy.success)
          return {
            data: { ...legacy.data, cart: {} },
            status: "migrated",
            notice:
              "Actualizamos el formato de datos de Rosita. Se conservó el contador técnico y el nuevo carrito comienza vacío.",
          };
      }
    }
    const result = envelopeSchema.safeParse(value);
    if (!result.success)
      return {
        data: empty(),
        status: "invalid",
        notice:
          "Los datos de Rosita no eran válidos. Se inició un estado vacío; la próxima modificación guardará un formato válido.",
      };
    const cart = normalizeCart(result.data.data.cart),
      repaired = JSON.stringify(cart) !== JSON.stringify(result.data.data.cart);
    return {
      data: { ...result.data.data, cart },
      status: repaired ? "repaired" : "loaded",
      notice: repaired
        ? "Ajustamos el carrito al catálogo y stock de demostración disponibles. Revisa las cantidades."
        : "",
    };
  } catch (error) {
    const invalid = error instanceof SyntaxError;
    return {
      data: empty(),
      status: invalid ? "invalid" : "unavailable",
      notice: invalid
        ? "No se pudo leer el contenido guardado de Rosita. Se inició un estado vacío sin afectar otros datos del navegador."
        : "El navegador no permite almacenamiento local. Puedes explorar, pero el carrito podría perderse al recargar.",
    };
  }
}
export function writeRositaState(
  state: RositaState,
  storage?: Storage,
): { ok: boolean; message?: string } {
  try {
    const data = stateSchema.parse(state);
    targetStorage(storage).setItem(
      STATE_KEY,
      JSON.stringify({
        version: STORAGE_VERSION,
        data: { ...data, cart: normalizeCart(data.cart) },
      }),
    );
    return { ok: true };
  } catch {
    return {
      ok: false,
      message:
        "No se pudieron guardar los datos de Rosita. Comprueba el almacenamiento del navegador.",
    };
  }
}
export function resetRositaStorage(storage?: Storage): {
  ok: boolean;
  message?: string;
} {
  try {
    const target = targetStorage(storage);
    const owned = Array.from({ length: target.length }, (_, i) =>
      target.key(i),
    ).filter(
      (key): key is string => key !== null && key.startsWith(STORAGE_PREFIX),
    );
    for (const key of owned) target.removeItem(key);
    return { ok: true };
  } catch {
    return {
      ok: false,
      message:
        "No se pudieron restablecer los datos locales. Los datos de otras aplicaciones se conservan.",
    };
  }
}
